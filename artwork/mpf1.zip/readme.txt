Original image by Lee Davidson.
http://members.lycos.co.uk/leeedavison/z80/mpf1/mpf_board.jpg
